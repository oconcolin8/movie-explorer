/*
  firestore.js Helper functions for reading and writing the user's
  watchlist in Cloud Firestore.

  Firestore data structure used by this app:
    users/                      top-level collection
      {uid}/                    one document per Firebase user (uid = user.uid)
        watchlist/              subcollection of saved movies
          {movie.id}/           one document per movie (keyed by TMDB movie ID)
            id, title, poster_path, release_date, vote_average

  Why a subcollection instead of an array on the user doc?
  Subcollections scale better and let us add or remove individual movies
  with a single setDoc or deleteDoc instead of reading and rewriting the whole array.
*/

// db is the Firestore instance initialized in firebase.js
import { db } from './firebase';

// Firestore SDK functions:
//   doc        creates a reference to a specific document path
//   setDoc     writes (or overwrites) a document at the given reference
//   collection creates a reference to a collection path
//   getDocs    fetches all documents in a collection
import { doc, setDoc, collection, getDocs } from 'firebase/firestore';

/*
  addToWatchlist
  Saves a movie to the logged-in user's watchlist subcollection in Firestore.

  Parameters:
    user  is the Firebase user object (provides user.uid for the document path)
    movie is the TMDB movie object (we save only the fields we need for display)

  We use setDoc (not addDoc) so the document ID is the TMDB movie ID.
  This means saving the same movie twice just overwrites the existing document
  rather than creating a duplicate.
*/
export async function addToWatchlist(user, movie) {
  try {
    /*
      Build the path: users/{uid}/watchlist/{movieId}
      String(movie.id) converts the numeric TMDB ID to a string,
      which is required for Firestore document IDs.
    */
    const ref = doc(db, 'users', user.uid, 'watchlist', String(movie.id));

    /*
      Write only the fields needed to render a MovieCard.
      We do not store the full TMDB response to keep Firestore read costs low.
    */
    await setDoc(ref, {
      id: movie.id,
      title: movie.title,
      poster_path: movie.poster_path,
      release_date: movie.release_date,
      vote_average: movie.vote_average,
    });

    console.log('Added to watchlist:', movie.title);
  } catch (err) {
    console.error('Error adding to watchlist:', err);
  }
}

/*
  getWatchlist
  Reads all saved movies from the logged-in user's watchlist subcollection.

  Parameters:
    user is the Firebase user object (provides user.uid)

  Returns:
    Array of movie objects (the data we stored with addToWatchlist).
    Returns an empty array on error so the UI does not crash.
*/
export async function getWatchlist(user) {
  try {
    /*
      Build a reference to the entire watchlist subcollection for this user.
      Path: users/{uid}/watchlist
    */
    const ref = collection(db, 'users', user.uid, 'watchlist');

    /*
      getDocs fetches every document in the collection in one request.
      snapshot is a QuerySnapshot that contains a docs array of
      DocumentSnapshot objects.
    */
    const snapshot = await getDocs(ref);

    /*
      Map each DocumentSnapshot to its plain data object.
      doc.data() strips away the Firestore metadata and returns the
      raw id, title, poster_path, release_date, vote_average we stored.
    */
    return snapshot.docs.map(doc => doc.data());
  } catch (err) {
    console.error('Error getting watchlist:', err);
    return []; // safe fallback, renders empty list instead of crashing
  }
}
