/*
  WatchlistPage.jsx Displays the logged-in user's saved movies.

  Props:
    user is the Firebase user object. Required to:
         1. Know whose Firestore watchlist to load.
         2. Guard the page and redirect to /login if no user is present.

  Data flow:
    On mount, read from Firestore (users/{uid}/watchlist) and render MovieCards.

  States:
    loading   is true while the Firestore fetch is in flight and shows a loading message.
    watchlist is the array of movie objects previously saved by addToWatchlist.
*/

// useState stores the watchlist array and loading flag
// useEffect triggers the Firestore fetch when the component mounts
import { useState, useEffect } from 'react';

// useNavigate redirects unauthenticated visitors to /login
import { useNavigate } from 'react-router-dom';

// getWatchlist is a Firestore helper that reads all saved movies for a user
import { getWatchlist } from '../services/firestore';

// MovieCard is the same card component used on the home page
import MovieCard from '../components/MovieCard';

function WatchlistPage({ user }) {
  /*
    watchlist is populated after the Firestore fetch completes.
    Starts as an empty array so the grid renders nothing until data arrives.
  */
  const [watchlist, setWatchlist] = useState([]);

  /*
    loading is true until the fetch finishes or we redirect.
    Prevents a flash of empty watchlist while data is still loading.
  */
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  /*
    Runs when the component mounts and any time user changes.
    Two cases:
      A: user is null, redirect to login (no watchlist without an account).
      B: user exists, fetch their watchlist from Firestore.

    user is in the dependency array so if someone logs in while this page
    is open (unlikely but possible), the watchlist loads immediately.
  */
  useEffect(() => {
    // Case A: unauthenticated, redirect and stop execution
    if (!user) {
      navigate('/login');
      return;
    }

    // Case B: authenticated, fetch movies from Firestore
    const fetchWatchlist = async () => {
      const movies = await getWatchlist(user); // reads users/{uid}/watchlist
      setWatchlist(movies);
      setLoading(false); // hide the loading message
    };

    fetchWatchlist();
  }, [user]); // re-run if the user object changes

  /*
    Show a loading indicator while the Firestore request is pending.
    Without this, the empty watchlist message would flash briefly
    before the real data arrives.
  */
  if (loading) {
    return <p>Loading your watchlist...</p>;
  }

  return (
    <div className="watchlist-page">
      <h1>My Watchlist</h1>

      {watchlist.length === 0 ? (
        /*
          Empty state shown when the user has never saved any movies.
          Showing a helpful message is better than a blank page which
          could look like a bug or a failed load.
        */
        <p>Your watchlist is empty. Search for movies to add some!</p>
      ) : (
        /*
          Render the saved movies in the same grid layout as the home page.
          Each MovieCard gets the user prop so the Add to Watchlist button
          still works from this page.
        */
        <ul className="movie-grid">
          {watchlist.map((movie) => (
            <MovieCard
              key={movie.id}   // unique TMDB ID as React key
              movie={movie}    // movie data saved in Firestore
              user={user}      // enables watchlist button on each card
            />
          ))}
        </ul>
      )}
    </div>
  );
}

export default WatchlistPage
