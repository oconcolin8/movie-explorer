/*
  MovieDetailPage.jsx Full detail view for a single movie.

  Loaded when the user navigates to /movie/:id.
  Makes three TMDB API calls on mount to gather:
    1. Movie details  (title, overview, genres, runtime, etc.)
    2. Cast credits   (top 10 cast members shown)
    3. User reviews   (author and truncated review text)

  Props:
    user is the Firebase user (passed through but not currently used here;
         available if you want to add watchlist functionality to this page).
*/

// useParams reads the :id segment from the URL
// useNavigate lets the Back button go to the previous page
import { useParams, useNavigate } from 'react-router-dom';

// TMDB service functions, each hits a different TMDB endpoint
import { getMovieDetails, getMovieCredits, getMovieReviews } from "../services/tmdb";

// useState stores the three pieces of fetched data
// useEffect triggers the fetch when the component mounts or id changes
import { useState, useEffect } from 'react';

function MovieDetailPage({ user }) {
    /*
      id is the TMDB movie ID extracted from the URL (e.g. /movie/27205 gives "27205").
      useParams reads it from the :id route parameter defined in App.jsx.
    */
    const { id } = useParams();

    // navigate(-1) goes back one entry in the browser history to the search results
    const navigate = useNavigate();

    /*
      details is the full movie object returned by TMDB's /movie/:id endpoint.
      Starts as null so we can show a loading indicator while the fetch is pending.
    */
    const [details, setDetails] = useState(null);

    /*
      credits is the array of cast members from TMDB's /movie/:id/credits endpoint.
      Each item has: id, name, character, profile_path.
      We only display the first 10 to keep the page manageable.
    */
    const [credits, setCredits] = useState([]);

    /*
      reviews is the array of user reviews from TMDB's /movie/:id/reviews endpoint.
      Each item has: id, author, content.
      Content is truncated to 300 characters in the render to avoid walls of text.
    */
    const [reviews, setReviews] = useState([]);

    /*
      Fetch all three data sets when the component mounts.
      id is in the dependency array so if the user navigates from one
      detail page to another, the data re-fetches for the new movie.

      We define fetchData as an async function inside useEffect because
      useEffect callbacks themselves cannot be async.
    */
    useEffect(() => {
        const fetchData = async () => {
            const movieDetails = await getMovieDetails(id);
            const movieCredits = await getMovieCredits(id);
            const movieReviews = await getMovieReviews(id);

            // Store all three results in state to trigger a re-render
            setDetails(movieDetails);
            setCredits(movieCredits);
            setReviews(movieReviews);
        }
        fetchData();
    }, [id]); // re-run if the movie ID in the URL changes

    return (
        <div className="detail-page">

            {/*
              Back button. navigate(-1) is equivalent to clicking the browser's
              back button and takes the user back to the search results on HomePage.
            */}
            <button onClick={() => navigate(-1)}>Back to Results</button>

            {/*
              Conditional render: show Loading until details arrives.
              details is null on first render because the fetch has not
              completed yet. Once setDetails is called, this re-renders
              with the full movie info.
            */}
            {!details ? (
                <p>Loading...</p>
            ) : (
                <div>
                    {/* Poster, w500 means a 500px wide image from TMDB's CDN */}
                    <img
                        src={`https://image.tmdb.org/t/p/w500${details.poster_path}`}
                        alt={details.title}
                    />

                    {/* Core movie info */}
                    <h1>{details.title}</h1>
                    <p>{details.tagline}</p>       {/* short marketing phrase */}
                    <p>{details.overview}</p>      {/* plot summary */}
                    <p>Release Date: {details.release_date}</p>
                    <p>Runtime: {details.runtime} minutes</p>
                    <p>Rating: {details.vote_average}</p>

                    {/*
                      Genres. TMDB returns an array of id and name objects.
                      We extract the name from each and join them into a string.
                    */}
                    <p>Genres: {details.genres.map(g => g.name).join(', ')}</p>

                    {/* Cast Section */}
                    <h2>Cast</h2>
                    <ul className="cast-list">
                        {/*
                          slice(0, 10) limits to the first 10 cast members.
                          TMDB returns the full cast in billing order so
                          the most prominent actors appear first.
                        */}
                        {credits.slice(0, 10).map((member) => (
                            <li key={member.id}>
                                {/*
                                  profile_path can be null if TMDB has no photo.
                                  We skip the img in that case to avoid
                                  rendering a broken image icon.
                                */}
                                {member.profile_path && (
                                    <img
                                        src={`https://image.tmdb.org/t/p/w200${member.profile_path}`}
                                        alt={member.name}
                                    />
                                )}
                                <p>{member.name} as {member.character}</p>
                            </li>
                        ))}
                    </ul>

                    {/* Reviews Section */}
                    <h2>Reviews</h2>
                    {reviews.length === 0 ? (
                        /* Empty state, many movies have no TMDB reviews */
                        <p>No reviews yet</p>
                    ) : (
                        <ul className="reviews-list">
                            {reviews.map((review) => (
                                <li key={review.id}>
                                    <h3>{review.author}</h3>
                                    {/*
                                      Truncate to 300 characters to keep the page
                                      readable. Some reviews are extremely long.
                                      The ... signals there is more text.
                                    */}
                                    <p>{review.content.slice(0, 300)}...</p>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            )}
        </div>
    )
}

export default MovieDetailPage
