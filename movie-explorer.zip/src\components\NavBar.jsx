/*
  NavBar.jsx Persistent top navigation bar shown on every page.

  Props:
    user is the Firebase user object (or null if not logged in).
         Controls which buttons are shown in the nav.

  Behaviour:
  Logged out: shows a Log In button that goes to /login.
  Logged in: shows the user's email, a My Watchlist link,
             and a Log Out button.
*/

// useNavigate lets us change the URL in response to button clicks
import { useNavigate } from 'react-router-dom';

// signOut is the Firebase function that ends the current auth session
import { signOut } from 'firebase/auth';

// auth is the shared Firebase Auth instance
import { auth } from '../services/firebase';

function NavBar({ user }) {
  // navigate is used to redirect after logout and for link buttons
  const navigate = useNavigate();

  /*
    handleLogout signs the user out of Firebase and redirects to /login.
    Wrapped in try/catch in case Firebase throws (e.g. network issue).
    After signOut, the onAuthStateChanged listener in App.jsx will set
    user back to null, which re-renders the navbar to its logged-out state.
  */
  const handleLogout = async () => {
    try {
      await signOut(auth);   // end the Firebase session
      navigate('/login');    // redirect to login page
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  return (
    <nav className="navbar">

      {/* App name, clicking always takes you home */}
      <span className="navbar-title" onClick={() => navigate('/')}>
        Movie Explorer
      </span>

      {/*
        Right side actions change based on auth state.
        React renders one branch or the other based on whether user is truthy.
      */}
      <div className="navbar-actions">
        {user ? (
          /*
            Logged in state: show the email so the user knows which
            account they are using, a watchlist link, and a logout button.
            The fragment groups the three elements without adding a DOM node.
          */
          <>
            <span>{user.email}</span>
            <button onClick={() => navigate('/watchlist')}>My Watchlist</button>
            <button onClick={handleLogout}>Log Out</button>
          </>
        ) : (
          /* Logged out state: just a button to go to the login page */
          <button onClick={() => navigate('/login')}>Log In</button>
        )}
      </div>

    </nav>
  );
}

export default NavBar
