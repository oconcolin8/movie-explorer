/*
  App.jsx Root component of the application.

  Responsibilities:
  1. Listen for Firebase auth state changes so every page knows
     whether a user is logged in or not.
  2. Lift the movies state up here so search results persist when
     the user navigates away from HomePage and comes back.
  3. Define the URL routes that map paths to page components.
*/

// Routes and Route are declarative routing components from React Router
import { Routes, Route } from 'react-router-dom'

// Page components, each one maps to a URL route below
import HomePage from './pages/HomePage'
import MovieDetailPage from './pages/MovieDetailPage'
import LoginPage from './pages/LoginPage'
import WatchlistPage from './pages/WatchlistPage'

// NavBar is rendered outside Routes so it appears on every page
import NavBar from './components/NavBar'

// useState stores reactive data and useEffect runs side effects
import { useState, useEffect } from 'react'

// onAuthStateChanged fires whenever the user logs in or out
import { onAuthStateChanged } from 'firebase/auth'

// auth is the Firebase Auth instance initialized in services/firebase.js
import { auth } from './services/firebase'

function App() {
  /*
    user is the currently logged-in Firebase user object, or null if
    nobody is logged in. Passed down to pages and components that need
    to know who is viewing the app (e.g. to show or hide the watchlist button).
  */
  const [user, setUser] = useState(null);

  /*
    movies is the array of search results from the last TMDB query.
    Stored here (not in HomePage) so the list survives navigation.
    If the user clicks into a movie detail page and then hits Back,
    the results are still there when HomePage remounts.
  */
  const [movies, setMovies] = useState([]);

  /*
    Subscribe to Firebase auth state when the app first mounts.
    onAuthStateChanged calls our callback immediately with the current
    user, then again any time the user logs in or out.
    Returning unsubscribe from useEffect cleans up the listener
    when the component unmounts and prevents memory leaks.
  */
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser); // null when logged out, user object when logged in
    });
    return unsubscribe; // cleanup, stop listening when App unmounts
  }, []); // empty array means this only runs once on mount

  return (
    <div>
      {/* NavBar sits outside Routes so it renders on every page */}
      <NavBar user={user} />

      {/*
        Routes looks at the current URL and renders the first Route
        whose path matches. Only one route renders at a time.
      */}
      <Routes>

        {/* /login is the authentication page for login and signup */}
        <Route path="/login" element={<LoginPage />} />

        {/*
          / is the home page with search form and results grid.
          We pass user so MovieCard can show the watchlist button,
          and movies and setMovies so search results persist across navigations.
        */}
        <Route
          path="/"
          element={
            <HomePage
              user={user}
              movies={movies}
              setMovies={setMovies}
            />
          }
        />

        {/*
          /movie/:id is the detail page for a single movie.
          :id is a URL parameter extracted with useParams() inside the page.
        */}
        <Route path="/movie/:id" element={<MovieDetailPage user={user} />} />

        {/* /watchlist shows the logged-in user's saved movies */}
        <Route path="/watchlist" element={<WatchlistPage user={user} />} />

      </Routes>
    </div>
  )
}

export default App
