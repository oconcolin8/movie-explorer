/*
  MovieCard.jsx Displays a single movie in the search results grid
  and on the Watchlist page.

  Props:
    movie is the movie object from TMDB (id, title, poster_path,
          release_date, vote_average)
    user  is the Firebase user object (or null if not logged in).
          Used to decide whether to show the Add to Watchlist button.
*/

// useNavigate allows programmatic navigation to the detail page on button click
import { useNavigate } from 'react-router-dom';

// addToWatchlist is a Firestore helper that saves a movie under the user's doc
import { addToWatchlist } from '../services/firestore';

// useState tracks whether the movie was just saved for success feedback
import { useState } from 'react';

function MovieCard({ movie, user }) {
  // navigate lets us push a new URL without a full page reload
  const navigate = useNavigate();

  /*
    saved is true for 3 seconds after the user clicks Add to Watchlist.
    Used to show a brief confirmation message.
    Resets to false automatically so the button is ready to be used again.
  */
  const [saved, setSaved] = useState(false);

  /*
    handleAddToWatchlist is called when the user clicks Add to Watchlist.
    1. Writes the movie to Firestore under the current user's watchlist.
    2. Sets saved to true so the success message appears.
    3. Resets saved after 3 seconds so the message disappears.
  */
  const handleAddToWatchlist = async () => {
    await addToWatchlist(user, movie); // write to Firestore
    setSaved(true);
    setTimeout(() => setSaved(false), 3000); // auto-hide after 3s
  };

  return (
    <div className="movie-card">

      {/*
        Poster image. TMDB serves images at various widths.
        w500 gives a 500px wide image, good for card thumbnails.
        poster_path is just the filename (e.g. /abc123.jpg),
        so we prepend the CDN base URL.
      */}
      <img
        src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
        alt={movie.title}
      />

      {/* Basic movie info shown on the card */}
      <h2>{movie.title}</h2>
      <p>{movie.release_date}</p>
      <p>{movie.vote_average}</p>

      {/*
        View Details navigates to the detail page for this movie.
        The URL uses the TMDB movie ID so the detail page can fetch
        full info from the API.
      */}
      <button onClick={() => navigate(`/movie/${movie.id}`)}>
        View Details
      </button>

      {/*
        Watchlist section only shows the button if a user is logged in.
        If not logged in, show a prompt to log in instead.
        This prevents calling Firestore with a null user which would error.
      */}
      {user ? (
        <div>
          <button onClick={handleAddToWatchlist}>
            Add to Watchlist
          </button>
          {/* Briefly shown after saving and disappears after 3 seconds */}
          {saved && <p className="success">Added to watchlist!</p>}
        </div>
      ) : (
        <p>Log in to save movies</p>
      )}

    </div>
  );
}

export default MovieCard
