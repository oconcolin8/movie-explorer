/*
  SearchForm.test.jsx Unit tests for the SearchForm component.

  What is tested:
    1. Valid input no error shown, onSearch callback called.
    2. Empty input "Please type a Movie" error shown.
    3. Input over 100 chars max length error shown.
    4. Whitespace only input treated as empty, same error as case 2.
    5. API not called when validation fails (guards against wasted requests).
*/

// render mounts a component into a virtual DOM for testing
// screen queries the rendered DOM (getByText, queryByRole, etc.)
import { render, screen } from '@testing-library/react';

// userEvent simulates user interactions more realistically than fireEvent
import userEvent from '@testing-library/user-event';

import SearchForm from '../components/SearchForm';

/*
  Mock the entire tmdb service module so no real HTTP requests are made.
  jest.fn().mockResolvedValue([]) makes searchMovies return an empty
  array immediately, allowing the form's async handler to complete.

  This mock applies to every test in this file.
*/
jest.mock('../services/tmdb', () => ({
  searchMovies: jest.fn().mockResolvedValue([]),
}));

// Import the mocked version so individual tests can spy on call counts
import { searchMovies } from '../services/tmdb';

/*
  describe groups all SearchForm tests under a shared label.
  This makes test output easier to read in the terminal.
*/
describe('SearchForm validation', () => {

  /*
    Test 1 Happy path.
    Type a valid movie title and click Search.
    Expected: no error paragraph rendered, and onSearch was called.
  */
  test('valid input submits without errors', async () => {
    // Create a mock function so we can assert it was called
    const onSearch = jest.fn();
    render(<SearchForm onSearch={onSearch} />);

    // Simulate typing "Inception" into the input field
    await userEvent.type(screen.getByPlaceholderText('Search Movies'), 'Inception');

    // Simulate clicking the Search button
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    // No error paragraph should be in the DOM
    expect(screen.queryByRole('paragraph')).not.toBeInTheDocument();

    // The parent's onSearch callback should have been invoked with results
    expect(onSearch).toHaveBeenCalled();
  });

  /*
    Test 2 Empty input validation.
    Click Search without typing anything.
    Expected: the "Please type a Movie" error message appears.
  */
  test('empty input shows required error', async () => {
    render(<SearchForm onSearch={jest.fn()} />);

    // Click Search immediately, input is empty
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    // The validation error should now be visible in the DOM
    expect(screen.getByText('Please type a Movie')).toBeInTheDocument();
  });

  /*
    Test 3 Max length validation.
    Type a string longer than 100 characters and click Search.
    Expected: the max length error message appears.
  */
  test('input over 100 characters shows max length error', async () => {
    render(<SearchForm onSearch={jest.fn()} />);

    // 'a'.repeat(101) creates a 101 character string, one over the limit
    await userEvent.type(screen.getByPlaceholderText('Search Movies'), 'a'.repeat(101));
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    expect(screen.getByText('Search must be less than 100 characters')).toBeInTheDocument();
  });

  /*
    Test 4 Whitespace only input validation.
    Spaces should not count as a valid query.
    The form uses query.trim() === "" to catch this case.
    Expected: same "Please type a Movie" error as empty input.
  */
  test('whitespace-only input shows required error', async () => {
    render(<SearchForm onSearch={jest.fn()} />);

    // Type only spaces, looks filled but should be treated as empty
    await userEvent.type(screen.getByPlaceholderText('Search Movies'), '   ');
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    expect(screen.getByText('Please type a Movie')).toBeInTheDocument();
  });

  /*
    Test 5 API not called on validation failure.
    If the form blocks submission, searchMovies should never be invoked.
    This guards against accidental API calls that waste quota.
  */
  test('API is not called when validation fails', async () => {
    // Reset call count from any previous test
    searchMovies.mockClear();

    render(<SearchForm onSearch={jest.fn()} />);

    // Click Search with empty input, validation should fail
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    // searchMovies should NOT have been called
    expect(searchMovies).not.toHaveBeenCalled();
  });

});
