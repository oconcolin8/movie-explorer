/*
  SearchForm.jsx Controlled input form for searching movies via the TMDB API.

  Props:
    onSearch(results) is a callback provided by HomePage.
                      Called with the array of results after a successful search,
                      so the parent can update its movie list state.

  Validation rules (checked before any API call is made):
    1. Query must not be empty or whitespace only.
    2. Query must be 100 characters or fewer.
*/

// useState manages the text input value and any validation error message
import { useState } from 'react';

// searchMovies sends a query to the TMDB search endpoint and returns results
import { searchMovies } from "../services/tmdb";

function SearchForm(props) {
  /*
    query mirrors the value of the text input.
    Kept in state so React controls the input (a controlled component),
    which makes validation and testing straightforward.
  */
  const [query, setQuery] = useState('');

  /*
    error holds a validation message string, or empty string when there is no error.
    Displayed below the input in red. Cleared as soon as the user starts typing.
  */
  const [error, setError] = useState('');

  /*
    handleSubmit runs when the form is submitted (Enter key or Search button).

    Steps:
    1. Prevent the browser's default form behaviour (page reload).
    2. Run client-side validation and return early with an error if invalid.
    3. Clear any previous error message.
    4. Call the TMDB API and pass the results up to the parent via onSearch.
  */
  const handleSubmit = async (event) => {
    // Stop the browser from navigating or reloading the page
    event.preventDefault();

    // Rule 1: empty or whitespace only input is not useful to search
    if (query.trim() === "") {
      return setError('Please type a Movie');
    }

    // Rule 2: TMDB URLs have a practical length limit and this also guards
    // against accidental paste of huge blocks of text
    if (query.length > 100) {
      return setError('Search must be less than 100 characters');
    }

    // All validation passed, clear any old error before fetching
    setError('');

    // Fetch results from TMDB and hand them to the parent component
    const results = await searchMovies(query);
    props.onSearch(results);
  };

  return (
    <form className="search-form" onSubmit={handleSubmit}>
      <label>Search Movies</label>

      {/*
        Controlled input: value is always in sync with the query state.
        onChange updates state on every keystroke and clears any error so
        the user does not see a stale message while they are still typing.
      */}
      <input
        className="search-input"
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setError(''); // clear error as soon as the user edits the field
        }}
        placeholder="Search Movies"
      />

      {/* Conditionally render the error paragraph only when error is non-empty */}
      {error && <p className="error">{error}</p>}

      {/* type submit triggers the form's onSubmit handler */}
      <button type="submit">Search</button>

    </form>
  );
}

export default SearchForm
