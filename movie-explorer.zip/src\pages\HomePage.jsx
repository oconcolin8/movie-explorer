/*
  HomePage.jsx The main search page of the app.

  Props:
    user      is the Firebase user object (or null). Forwarded to each MovieCard
              so it can show the Add to Watchlist button for logged-in users.
    movies    is the array of movie objects from the last search. Owned by App.jsx
              (not here) so the list survives navigating away and coming back.
    setMovies is the setter for the movies array. Passed to SearchForm so the results
              can be stored at the App level after each search.

  Layout:
    SearchForm on top with a results grid of MovieCards below.
*/

// SearchForm is the input and submit button at the top of the page
import SearchForm from '../components/SearchForm'

// MovieCard renders one movie tile in the grid
import MovieCard from '../components/MovieCard'

function HomePage({ user, movies, setMovies }) {

  /*
    handleSearchResults is called by SearchForm after a successful TMDB query.
    Receives the array of results and stores them in the App-level state
    via setMovies. Storing results in App (not here) is what makes them
    persist when the user navigates to a detail page and hits Back.
  */
  const handleSearchResults = (results) => {
    setMovies(results);
  };

  return (
    <div className="home-page">

      {/* onSearch wires the form's callback to our local handler above */}
      <SearchForm onSearch={handleSearchResults} />

      {/*
        Movie results grid.
        movies starts as an empty array so nothing renders until the first search.
        Each MovieCard needs a unique key prop and we use the TMDB movie ID.
        user is forwarded so each card can show the watchlist button.
      */}
      <ul className="movie-grid">
        {movies.map((movie) => (
          <MovieCard
            key={movie.id}   // unique TMDB ID prevents React key warnings
            movie={movie}    // full movie object with title, poster, etc.
            user={user}      // null or Firebase user, controls watchlist button
          />
        ))}
      </ul>

    </div>
  );
}

export default HomePage
