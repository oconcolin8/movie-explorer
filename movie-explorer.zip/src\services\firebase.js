/*
  firebase.js Initializes the Firebase app and exports the two
  Firebase services used in this project:

    auth is Firebase Authentication (login, signup, logout)
    db   is Cloud Firestore (stores each user's watchlist)

  All config values are stored in a .env file (VITE_ prefix makes them
  available to Vite at build time). They are never hardcoded here so
  secrets do not end up in the git repository.
*/

// initializeApp connects the SDK to your Firebase project using the config
import { initializeApp } from "firebase/app";

// getAuth returns the Auth service for the given Firebase app
import { getAuth } from "firebase/auth";

// getFirestore returns the Firestore database instance
import { getFirestore } from "firebase/firestore";

/*
  firebaseConfig identifies which Firebase project to connect to.
  Each value maps to a field in your Firebase project settings.
  Loaded from environment variables via Vite's import.meta.env.
*/
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,               // project API key
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,       // e.g. myapp.firebaseapp.com
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,         // e.g. movie-explorer-abc12
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET, // Cloud Storage bucket
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID, // for FCM
  appId: import.meta.env.VITE_FIREBASE_APP_ID,                 // unique app identifier
};

// Initialize Firebase, must be called once before using any Firebase services
const app = initializeApp(firebaseConfig);

/*
  auth is exported so any component can call Firebase Auth methods:
  signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, etc.
  Also used by onAuthStateChanged in App.jsx to track login state.
*/
export const auth = getAuth(app);

/*
  db is exported so Firestore helper functions in firestore.js can
  read and write documents (e.g. each user's saved watchlist).
*/
export const db = getFirestore(app);
