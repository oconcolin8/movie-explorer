/*
  tmdb.js All functions that communicate with The Movie Database (TMDB) API.

  Authentication:
    TMDB uses Bearer token auth. The token is stored in .env as
    VITE_TMDB_API_KEY and injected at build time by Vite via import.meta.env.
    It is attached to every request in the Authorization header.

  Base URL: https://api.themoviedb.org/3/
  Docs:     https://developer.themoviedb.org/docs

  Functions exported:
    searchMovies(query)    searches by keyword and returns an array of movie summaries
    getMovieDetails(id)    returns full info for one movie (title, overview, genres, etc.)
    getMovieCredits(id)    returns the cast list for one movie
    getMovieReviews(id)    returns user reviews for one movie
*/

/*
  API_TOKEN is loaded from the environment so the key is never committed to git.
  In Vite, any .env variable prefixed with VITE_ is exposed to the frontend
  bundle. Do not store sensitive secrets (server keys, admin tokens) here.
*/
const API_TOKEN = import.meta.env.VITE_TMDB_API_KEY;

/*
  searchMovies
  Searches TMDB for movies matching the given keyword string.

  Parameters:
    query is the search term typed by the user (already validated in SearchForm)

  Returns:
    Array of movie summary objects. Each item contains at minimum:
    id, title, poster_path, release_date, vote_average.
    Returns undefined on network or API error.

  TMDB endpoint: GET /3/search/movie
  Key query params:
    include_adult=false filters out adult content
    language=en-US      returns English metadata
    page=1              only the first page of results (20 items max)
*/
export async function searchMovies(query) {
    try {
        // Embed the user's query at the end of the URL as a query parameter
        const url = `https://api.themoviedb.org/3/search/movie?include_adult=false&language=en-US&page=1&query=${query}`;

        const response = await fetch(url, {
            method: 'GET',   // reading data, not modifying anything on the server
            headers: {
                accept: 'application/json',            // expect JSON back
                Authorization: `Bearer ${API_TOKEN}`   // prove we are an authorized client
            }
        });

        // Parse the JSON response body into a JavaScript object
        const data = await response.json();

        /*
          TMDB wraps results inside a results array along with pagination info.
          We only need the array itself and the rest (page, total_pages, etc.) is
          not used in this app.
        */
        return data.results;
    } catch (error) {
        // Catches network failures, bad JSON, expired tokens, etc.
        console.error("Error searching movies", error);
    }
}

/*
  getMovieDetails
  Fetches the full detail record for a single movie by its TMDB ID.

  Parameters:
    id is the TMDB movie ID (a number, comes from the :id URL param)

  Returns:
    A movie detail object including: title, tagline, overview, poster_path,
    release_date, runtime, vote_average, genres (array of id and name).

  TMDB endpoint: GET /3/movie/{id}
*/
export async function getMovieDetails(id) {
    try {
        // TMDB detail endpoint, the movie ID goes directly in the URL path
        const url = `https://api.themoviedb.org/3/movie/${id}`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: `Bearer ${API_TOKEN}`
            }
        });

        // Parse the JSON response body
        const data = await response.json();

        // Return the full object, MovieDetailPage uses many fields from it
        return data;
    } catch (error) {
        console.error("Error getting movie details", error);
    }
}

/*
  getMovieCredits
  Fetches the cast list for a single movie.

  Parameters:
    id is the TMDB movie ID

  Returns:
    Array of cast member objects. Each item contains:
    id, name, character, profile_path (may be null if no photo available).
    The array is ordered by billing order with lead actors first.

  TMDB endpoint: GET /3/movie/{id}/credits
*/
export async function getMovieCredits(id) {
    try {
        const url = `https://api.themoviedb.org/3/movie/${id}/credits`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: `Bearer ${API_TOKEN}`
            }
        });

        const data = await response.json();

        /*
          The credits response has two arrays: cast and crew.
          We only need cast (the actors) since crew (directors, etc.) is not shown.
        */
        return data.cast;
    } catch (error) {
        console.error("Error getting movie credits", error);
    }
}

/*
  getMovieReviews
  Fetches user-submitted reviews for a single movie.

  Parameters:
    id is the TMDB movie ID

  Returns:
    Array of review objects. Each item contains:
    id, author, content (the full review text, often very long).
    Content is truncated to 300 chars in MovieDetailPage before rendering.

  TMDB endpoint: GET /3/movie/{id}/reviews
*/
export async function getMovieReviews(id) {
    try {
        const url = `https://api.themoviedb.org/3/movie/${id}/reviews`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: `Bearer ${API_TOKEN}`
            }
        });

        const data = await response.json();

        /*
          Same pattern as searchMovies. TMDB wraps the list in a results array.
          We return just the array.
        */
        return data.results;
    } catch (error) {
        console.error("Error getting movie reviews", error);
    }
}
